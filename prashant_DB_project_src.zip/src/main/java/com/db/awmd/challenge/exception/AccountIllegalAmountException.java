package com.db.awmd.challenge.exception;

//pkm
public class AccountIllegalAmountException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AccountIllegalAmountException(String message) {
		super(message);
	}
}
