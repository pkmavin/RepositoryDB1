package com.db.awmd.challenge.common;

public class Constants {

}
